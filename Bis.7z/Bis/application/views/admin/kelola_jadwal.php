<!DOCTYPE html>
<html>
<head>
    <title>Kelola Jadwal - Admin</title>
    <link rel="stylesheet" href="<?= base_url('Assets/css/bootstrap.min.css') ?>">
</head>
<body>
    
    <?php include 'include/nav.php'; ?>

    <div class="container-fluid my-4">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Daftar Jadwal</div>
                    <div class="card-body">
                        <table class="table table-condensed table-hover">
                            <thead>
                                <tr>
                                    <td>No</td>
                                    <td>Nama Bis</td>
                                    <td>Asal</td>
                                    <td>Tujuan</td>
                                    <td>Tanggal Berangkat</td>
                                    <td>Tanggal Sampai</td>
                                    <td>Kelas</td>
                                    <td>Aksi</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php foreach ($jadwal as $jd):?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= $jd->nama_bis ?></td>
                                    <td><?= $jd->ASAL ?></td>
                                    <td><?= $jd->TUJUAN ?></td>
                                    <td><?= $jd->tgl_berangkat ?></td>
                                    <td><?= $jd->tgl_sampai ?></td>
                                    <td><?= $jd->kelas ?></td>
                                    <td>
                                        <div class='btn-group btn-group-sm'>
                                            <a class="btn btn-danger" href="<?= base_url('hapusJadwal/'. $jd->id) ?>">Hapus</a>
                                            <a class="btn btn-primary" href="<?= base_url('admin/dashboard/edit-jadwal/'. $jd->id) ?>">Edit</a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Form Tambah Jadwal</div>
                        <div class="card-body">
                            <form action="<?= base_url('tambahJadwal')?>" method="POST">
                            <div class="form-group">
                                <label>Nama Bis</label>
                                 <input type="text" name="nama_bis" placeholder="Nama Bis" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label>Terminal Asal</label>
                                 <select name="asal" class="form-control" required>
                                 <?php foreach ($terminal as $ter): ?>
                                    <option value="<?= $ter->id ?>"><?= $ter->nama_terminal ?></option>
                                 <?php endforeach ?>    
                                 </select>
                            </div>

                            <div class="form-group">
                                <label>Terminal Tujuan</label>
                                <select name="tujuan" class="form-control"required>
                                <?php foreach ($terminal as $ter): ?>
                                    <option value="<?= $ter->id ?>"><?= $ter->nama_terminal ?></option>
                                 <?php endforeach ?>
                                 </select>
                            </div>

                            <div class="form-group">
                                <label>Tanggal Berangkat</label>
                                <input type="datetime-local" name="tgl_berangkat" min="<?= date('Y-m-d/TH:i') ?>" value='<?= date('Y-m-d/TH:i') ?>' class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label>Tanggal Sampai</label>
                                <input type="datetime-local" name="tgl_sampai" min='<?= date('Y-m-d/TH:i') ?>' value='<?= date('Y-m-d/TH:i') ?>' class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label>Kelas</label>
                                <select name="kelas" class="form-control" required>
                                    <option value="EKSEKUTIF">EKSEKUTIF</option>
                                    <option value="EKONOMI">EKONOMI</option>
                                    <option value="BISNIS">BISNIS</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Harga</label>
                                <input type="number" name='harga' placeholder='Harga' class='form-control' required>
                            </div>

                        <button class="btn btn-block btn-success">Tambah Jadwal</button>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
    </div>

    <script src="<?= base_url('Assets/js/bootstrap.min.js') ?>"></script>
</body>
</html>