<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="<?= base_url('Assets/css/bootstrap.min.css') ?>">
</head>
<body>

    <?php include 'include/nav.php'; ?>

    <div class="container-fluid my-4">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Daftar Terminal</div>
                    <div class="card-body">
                        <table class="table table-condensed table-hover">
                            <thead>
                                <tr>
                                    <td>No</td>
                                    <td>Nama Terminal</td>
                                    <td>Aksi</td>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $no = 1; ?>
                            <?php foreach ($terminal as $ter): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= $ter->nama_terminal ?></td>
                                    <td>
                                    <a class="text-danger" href="<?= base_url('hapusTerminal/'.$ter->id)?>">Hapus </a>
                                    <a href="<?= base_url('admin/dashboard/edit/'.$ter->id) ?>">Edit </a>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Form Tambah Terminal</div>
                        <div class="card-body">
                            <form action="<?= base_url('tambahTerminal')?>" method="POST">
                            <div class="form-group">
                                <label>Nama Terminal</label>
                                 <input type="text" class="form_control" name="terminal" placeholder="Nama Terminal">
                            </div>
                        <button class="btn btn-block btn-success">Tambah Terminal</button>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
    </div>

    <script src="<?= base_url('Assets/js/bootstrap.min.js') ?>"></script>
</body>
</html>