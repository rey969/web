<!DOCTYPE html>
<html>
<head>
    <title>Konfirmasi Pembayaran - Admin</title>
    <link rel="stylesheet" href="<?= base_url('Assets/css/bootstrap.min.css') ?>">
</head>
<body>
    
    <?php include 'include/nav.php'; ?>

    <div class="container-fluid my-4">
        <h2 class="text-center">Daftar Pelanggan Yang Mengirim Bukti Pembayaran</h2>
        <div class="row">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No Pembayaran</th>
                                    <th>No Tiket</th>
                                    <th>Total Pembayaran</th>
                                    <th width="20%">Bukti Pembayaran</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($list as $li): ?>
                                <tr>
                                    <td><?= $li->no_pembayaran ?></td>
                                    <td><?= $li->no_tiket ?></td>
                                    <td><?= $li->total_pembayaran ?></td>
                                    <td>
                                        <a href="<?= base_url('Assets/bukti/'.$li->bukti) ?>" target="_blank">
                                            <img width="50%" src="<?= base_url('Assets/bukti/'.$li->bukti) ?>" alt="">
                                        </a>
                                    </td>
                                    <td>
                                        <div>
                                            <a onclick='return confirm("Yakin Ingin Verifikasi No. Pembayaran <?= $li->no_pembayaran ?> ?")' href="<?= base_url('Verifikasi/'.$li->id) ?>" class='btn btn-success'>Verifikasi</a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>            
        </div>
    </div>
            

    <script src="<?= base_url('Assets/js/bootstrap.min.js') ?>"></script>
</body>
</html>