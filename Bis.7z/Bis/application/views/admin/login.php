<!DOCTYPE html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="<?= base_url('Assets/css/bootstrap.min.css') ?>">
</head>
<body>
    <div class="row justify-content-center my-5 container-fluid">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-dark text-white text-center">Login sebagai Admin</div>
                <div class="card-body">

                    <form action="prosesLogin" method="POST">
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="username" placeholder="Username" class="form-control">
                        </div>

                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" placeholder="Password" class="form-control">
                        </div>

                        <button class="btn btn-success btn-block">Login</button>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url('Assets/js/bootstrap.min.js') ?>"></script>
</body>
</html>