
    <script src="<?= base_url('Assets/js/bootstrap.min.js') ?>"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>

    <script>
        
        $('#foto').change(function(){
            var kursi = $('#select_kursi').val();
            var button = $('#btn_konfirmasi');
            var pesan = $('#pesan');

            if(kursi === "0"){
                button.attr("disabled",true);
                pesan.text("Pastikan Anda Memilih Kursi");
                pesan.addClass('text-danger');
            }else{
                button.attr("disabled",false);
                pesan.addClass('d_none');
                pesan.removeClass('text-danger');
            }
        });
    </script>


</body>
</html>