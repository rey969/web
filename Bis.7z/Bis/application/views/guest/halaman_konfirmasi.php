<div class="container-fluid">
    <div class="row justify-content-center my-5">
        <div class="col-md-5">
            <?php if($this->session->flashdata('pesan') !== null): ?>
            <div class="alert alert-success">
                <?= $this->session->flashdata('pesan') ?>
            </div>

            <?php endif; ?>

            <div class="card">
                <div class="card-header bg-dark text-center text-white">
                    Konfirmasi Pembayaran
                </div>
                <div class="card-body">
                    <form action="<?= base_url('cekKonfirmasi') ?>" method="POST">
                        <div class="form-group">
                            <label>Kode Booking</label>
                            <input type="text" name='kode' class="form-control" placeholder="Kode Booking">
                        </div>
                        <button class="btn btn-dark float-right">Cek Kode Booking</button>
                    </form>
                </div>
            </div>
            <hr>
            <?php if(isset($_GET['kode'])): ?>
            <h4>Kode Booking : <?= $_GET['kode'] ?></h4>
            <div class="card">
                <div class="card-header bg-dark text-center text-white">
                    Detail Pembayaran Anda
                </div>
                <div class="card-body">
                    <h1 class='text-center'>
                        <?php if($no_tiket->status === '0' || $no_tiket->status === '1'): ?>
                            <i class="fa fa-times text-danger"></i>Belum Dibayar
                        <?php elseif($no_tiket->status === '2'): ?>
                        <i class="fa fa-check text-success"></i>Sudah Dibayar

                        <?php endif; ?>
                    </h1>
                    <div class="table-responsive">
                        <table class='table table-bordered'>
                            <thead>
                                <tr>
                                    <th>Nama</th>
                                    <th>Identitas</th>
                                    <th>Nomor Kursi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($detail as $dt): ?>
                                <tr>
                                    <td><?= $dt->nama ?></td>
                                    <td><?= $dt->no_identitas ?></td>
                                    <td><?= $dt->kursi ?></td>
                                </tr>
                            <?php endforeach;?>
                            </tbody>
                        </table>
                        <p><b>Total Pembayaran Anda : Rp <?= $no_tiket->total_pembayaran ?></b></p>
                        <?php if($no_tiket->status === '0'): ?>
                        <p class='text-danger'>Silahkan Kirim Bukti Pembayaran</p>
                        <?= form_open_multipart("kirimKonfirmasi", array('id' => 'konfirmasi')); ?>

                        <input type="hidden" name='no_pembayaran' value='<?= $no_tiket->no_tiket ?>'>
                        <img id="img_kursi" class='img_fluid' src="<?= base_url('Assets/denah/denah_bus.jpg') ?>" alt="" width="400px">

                        <select class='form-control' name="kursi" id="select_kursi" required>
                            <option value="0" disabled selection>Pilih Kursi</option>
                            <?php for ($i=1; $i<=33; $i++):?>
                                <option value="<?= $i ?>" ><?= $i ?></option>
                            <?php endfor; ?>
                        </select>


                        <br>
                        <p>Foto Bukti Pembayaran</p>
                        <input id="foto" type="file" name='gambar' class='form-control' required>
                        <br>
                        <p class="d-none" id="pesan"></p>
                        <button id="btn_konfirmasi" type='submit' class='btn btn-dark btn-block'>Kirim Bukti Pembayaran</button>
                        
                        <?= form_close(); ?>
                        <?php else: ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

