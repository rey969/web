-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2019 at 03:54 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

CREATE DATABASE db_bis;
USE db_bis;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_bis`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE `jadwal` (
  `id` int(11) NOT NULL,
  `nama_bis` varchar(255) NOT NULL,
  `asal` int(11) NOT NULL,
  `tujuan` int(11) NOT NULL,
  `tgl_berangkat` datetime NOT NULL,
  `tgl_sampai` datetime NOT NULL,
  `kelas` varchar(100) NOT NULL,
  `harga` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jadwal`
--

INSERT INTO `jadwal` (`id`, `nama_bis`, `asal`, `tujuan`, `tgl_berangkat`, `tgl_sampai`, `kelas`, `harga`, `status`) VALUES
(6, 'Patas', 2, 3, '2019-07-09 14:30:00', '2019-07-09 19:30:00', 'EKSEKUTIF', '100000', 0),
(7, 'Doa Ibu', 3, 1, '2019-07-10 09:00:00', '2019-07-10 15:30:00', 'EKSEKUTIF', '150000', 0),
(8, 'Dewi Sri 2', 2, 1, '2019-07-08 09:00:00', '2019-07-08 13:20:00', 'EKSEKUTIF', '50000', 0),
(9, 'Dewi Sri 3', 1, 3, '2019-07-08 10:35:00', '2019-07-08 18:35:00', 'EKSEKUTIF', '150000', 0),
(10, 'Dewi Sri', 1, 2, '2019-07-08 10:00:00', '2019-07-08 14:30:00', 'EKSEKUTIF', '50000', 0),
(11, 'Dewi Sri 4', 3, 1, '2019-07-08 12:00:00', '2019-07-08 19:30:00', 'EKSEKUTIF', '150000', 0),
(12, 'Rejeki Bapak', 2, 3, '2019-07-08 15:30:00', '2019-07-08 21:00:00', 'EKSEKUTIF', '100000', 0),
(13, 'Rejeki Bapak 2', 3, 2, '2019-07-08 08:00:00', '2019-07-08 14:30:00', 'EKSEKUTIF', '100000', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id` int(11) NOT NULL,
  `no_pembayaran` varchar(255) NOT NULL,
  `no_tiket` varchar(100) NOT NULL,
  `total_pembayaran` varchar(255) NOT NULL,
  `bukti` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id`, `no_pembayaran`, `no_tiket`, `total_pembayaran`, `bukti`, `status`) VALUES
(1, 'AC001', 'T001', '300000', 'Inkedsoal-2a_LI.jpg', 2),
(2, 'AC002', 'T002', '300000', 'Inkedsoal-2a_LI1.jpg', 2),
(3, 'AC003', 'T003', '300000', 'Inkedsoal-2a_LI2.jpg', 2),
(4, 'AC004', 'T004', '250000', 'Inkedsoal-2a_LI3.jpg', 2),
(5, 'AC005', 'T005', '250000', NULL, 0),
(6, 'AC006', 'T006', '250000', 'Inkedsoal-2a_LI4.jpg', 1),
(8, 'AC007', 'T007', '250000', 'Inkedsoal-2a_LI6.jpg', 1),
(9, 'AC008', 'T008', '250000', 'Inkedsoal-2a_LI7.jpg', 1),
(10, 'AC009', 'T009', '250000', NULL, 0),
(11, 'AC0010', 'T0010', '250000', NULL, 0),
(12, 'AC0011', 'T0011', '350000', 'Inkedsoal-2a_LI8.jpg', 0),
(13, 'AC0012', 'T0012', '350000', 'Inkedsoal-2a_LI9.jpg', 2),
(14, 'AC0013', 'T0013', '350000', NULL, 0),
(15, 'AC0014', 'T0014', '350000', 'Inkedsoal-2a_LI10.jpg', 2),
(16, 'AC0015', 'T0015', '350000', 'Inkedsoal-2a_LI11.jpg', 2),
(17, 'AC0016', 'T0016', '350000', NULL, 0),
(18, 'AC0017', 'T0017', '700000', NULL, 0),
(19, 'AC0018', 'T0018', '100000', 'Inkedsoal-2a_LI12.jpg', 1),
(20, 'AC0019', 'T0019', '50000', 'Inkedsoal-2a_LI13.jpg', 1),
(21, 'AC0020', 'T0020', '50000', 'Inkedsoal-2a_LI14.jpg', 1),
(22, 'AC0021', 'T0021', '50000', 'Inkedsoal-2a_LI15.jpg', 1),
(23, 'AC0022', 'T0022', '50000', 'Inkedsoal-2a_LI16.jpg', 1),
(24, 'AC0023', 'T0023', '50000', 'Inkedsoal-2a_LI17.jpg', 1),
(25, 'AC0024', 'T0024', '50000', 'Inkedsoal-2a_LI18.jpg', 1),
(26, 'AC0025', 'T0025', '50000', 'Inkedsoal-2a_LI19.jpg', 1),
(27, 'AC0026', 'T0026', '50000', 'Inkedsoal-2a_LI20.jpg', 1),
(28, 'AC0027', 'T0027', '50000', 'Inkedsoal-2a_LI21.jpg', 1),
(29, 'AC0028', 'T0028', '50000', 'Inkedsoal-2a_LI22.jpg', 1),
(30, 'AC0029', 'T0029', '50000', 'Inkedsoal-2a_LI23.jpg', 1),
(31, 'AC0030', 'T0030', '50000', 'Inkedsoal-2a_LI24.jpg', 1),
(32, 'AC0031', 'T0031', '50000', 'Inkedsoal-2a_LI25.jpg', 1),
(33, 'AC0032', 'T0032', '50000', NULL, 0),
(34, 'AC0033', 'T0033', '50000', 'Inkedsoal-2a_LI27.jpg', 2),
(35, 'AC0034', 'T0034', '50000', 'Inkedsoal-2a_LI28.jpg', 2),
(36, 'AC0035', 'T0035', '50000', NULL, 0),
(37, 'AC0036', 'T0036', '50000', NULL, 0),
(38, 'AC0037', 'T0037', '50000', NULL, 0),
(39, 'AC0038', 'T0038', '50000', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `penumpang`
--

CREATE TABLE `penumpang` (
  `id` int(11) NOT NULL,
  `nomor_tiket` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `no_identitas` varchar(255) NOT NULL,
  `kursi` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penumpang`
--

INSERT INTO `penumpang` (`id`, `nomor_tiket`, `nama`, `no_identitas`, `kursi`) VALUES
(1, 'T001', 'Yudhi', '35', 0),
(2, 'T002', 'Abd', '12', 0),
(3, 'T003', 'Yudhi', '35', 0),
(4, 'T004', 'Abd', '35', 0),
(5, 'T005', 'Abd', '12', 0),
(6, 'T006', 'Abd', '12', 0),
(7, 'T007', 'Abd', '12', 0),
(8, 'T007', 'Abd', '12', 0),
(9, 'T008', 'Abd', '35', 0),
(10, 'T009', 'Abd', '12', 0),
(11, 'T0010', 'Abd', '12', 0),
(12, 'T0011', 'Yudhi', '35', 0),
(13, 'T0012', 'Yudhi', '35', 0),
(14, 'T0013', 'Yudhi', '35', 0),
(15, 'T0014', 'Abd', '12', 0),
(16, 'T0015', 'Yudhi', '35', 0),
(17, 'T0016', 'Yudhi', '12', 0),
(18, 'T0017', 'Yudhi', '35', 0),
(19, 'T0017', 'dab', '123', 0),
(20, 'T0018', 'Yudhi', '12', 0),
(21, 'T0018', 'dab', '123', 0),
(22, 'T0019', 'murti', '11222', 0),
(23, 'T0020', 'murti', '11222', 0),
(24, 'T0021', 'Abd', '12', 0),
(25, 'T0022', 'Abd', '12', 0),
(26, 'T0023', 'Abd', '12', 0),
(27, 'T0024', 'Abd', '12', 0),
(28, 'T0025', 'Abd', '1277', 0),
(29, 'T0026', 'Abd', '127722', 0),
(30, 'T0027', 'Abd', '12772233', 0),
(31, 'T0028', 'Abd', '12772233333', 0),
(32, 'T0029', 'Abd', '1824', 0),
(33, 'T0030', 'Abd', '182433', 0),
(34, 'T0031', 'Abd', '127722', 0),
(35, 'T0032', 'Abd', '127722', 0),
(36, 'T0033', 'Abd', '35', 0),
(37, 'T0034', 'Abd', '12', 0),
(38, 'T0035', 'Abd', '12', 13),
(39, 'T0036', 'Yudhi', '35', 10),
(40, 'T0037', 'Yudhi', '35', 11),
(41, 'T0038', 'Yudhi', '35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `terminal`
--

CREATE TABLE `terminal` (
  `id` int(11) NOT NULL,
  `nama_terminal` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `terminal`
--

INSERT INTO `terminal` (`id`, `nama_terminal`) VALUES
(1, 'Pemalang'),
(2, 'Semarang'),
(3, 'Surabaya'),
(4, 'Pekalongan');

-- --------------------------------------------------------

--
-- Table structure for table `tiket`
--

CREATE TABLE `tiket` (
  `id` int(11) NOT NULL,
  `nomor_tiket` varchar(255) NOT NULL,
  `id_jadwal` int(11) NOT NULL,
  `nama_pemesan` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `no_telepon` varchar(15) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tiket`
--

INSERT INTO `tiket` (`id`, `nomor_tiket`, `id_jadwal`, `nama_pemesan`, `email`, `no_telepon`, `alamat`) VALUES
(1, 'T001', 1, 'Yudhi', 'yudhipamungkas18@gmail.com', '123', 'ASW'),
(2, 'T002', 2, 'Abdul', 'abdul@gmail.com', '08282891', 'adada'),
(3, 'T003', 2, 'Yudhi', 'yudhipamungkas18@gmail.com', '08282891', 'adadada'),
(4, 'T004', 3, 'Abdul', 'abdul@gmail.com', '123', 'adwdwawd'),
(5, 'T005', 3, 'Abdul', 'abdul@gmail.com', '123', 'sdsdsds'),
(6, 'T006', 3, 'Abdul', 'abdul@gmail.com', '08282891', 'mnnn'),
(7, 'T007', 3, 'Abdul', 'abdul@gmail.com', '08282891', 'mmmm'),
(8, 'T007', 3, 'Abdul', 'abdul@gmail.com', '08282891', 'mmmn'),
(9, 'T008', 3, 'Abdul', 'abdul@gmail.com', '08282891', 'jnkjn'),
(10, 'T009', 3, 'Abdul', 'abdul@gmail.com', '123', 'kklhnkj'),
(11, 'T0010', 3, 'Abdul', 'abdul@gmail.com', '123', 'dwada'),
(12, 'T0011', 4, 'Yudhi', 'yudhipamungkas18@gmail.com', '123', 'sqss'),
(13, 'T0012', 4, 'Yudhi', 'yudhipamungkas18@gmail.com', '123', 'sdsas'),
(14, 'T0013', 4, 'Yudhi', 'yudhipamungkas18@gmail.com', '08282891', 'dsfefsf'),
(15, 'T0014', 4, 'Abdul', 'abdul@gmail.com', '08282891', ',m.m,kjhk'),
(16, 'T0015', 4, 'Yudhi', 'yudhipamungkas18@gmail.com', '08282891', 'dff'),
(17, 'T0016', 4, 'Yudhi', 'yudhipamungkas18@gmail.com', '08282891', 'sdawda'),
(18, 'T0017', 4, 'Yudhi', 'yudhipamungkas18@gmail.com', '08282891', 'sdsdasd'),
(19, 'T0018', 10, 'Yudhi', 'yudhipamungkas18@gmail.com', '08282891', 'edsdad'),
(20, 'T0019', 10, 'admadimurtiwiakan', 'admad@gmail.com', '0111', 'semarang'),
(21, 'T0020', 10, 'Abdul', 'yudhipamungkas18@gmail.com', '08282891', 'UU'),
(22, 'T0021', 10, 'Yudhi', 'pendapp@dina.com', '123', 'df'),
(23, 'T0022', 10, 'Yudhi', 'pendapp@dina.com', '123', 'df'),
(24, 'T0023', 10, 'Yudhi', 'pendapp@dina.com', '123', 'df'),
(25, 'T0024', 10, 'Yudhi', 'pendapp@dina.com', '123', 'df'),
(26, 'T0025', 10, 'Yudhi', 'pendapp@dina.com', '123', 'df'),
(27, 'T0026', 10, 'Yudhi', 'pendapp@dina.com', '123', 'df'),
(28, 'T0027', 10, 'Yudhi', 'pendapp@dina.com', '123', 'df'),
(29, 'T0028', 10, 'Yudhi', 'pendapp@dina.com', '123', 'df'),
(30, 'T0029', 10, 'Yudhi', 'pendapp@dina.com', '123', 'df'),
(31, 'T0030', 10, 'Yudhi', 'pendapp@dina.com', '123', 'df'),
(32, 'T0031', 10, 'Abdul', 'abdul@gmail.com', '123', 'sdsdassa'),
(33, 'T0032', 10, 'Abdul', 'abdul@gmail.com', '123', 'sdsdassa'),
(34, 'T0033', 10, 'Yudhi', 'yudhipamungkas18@gmail.com', '08282891', 'gyugu'),
(35, 'T0034', 10, 'Yudhi', 'yudhipamungkas18@gmail.com', '0111', 'mbkjk'),
(36, 'T0035', 10, 'Yudhi', 'yudhipamungkas18@gmail.com', '0111', 'mbkjk'),
(37, 'T0036', 10, 'Abdul', 'pendexp@dina.com', '08282891', 'wdwd'),
(38, 'T0037', 10, 'Yudhi', 'yudhipamungkas18@gmail.com', '123', 'asasasas'),
(39, 'T0038', 10, 'Yudhi', 'yudhipamungkas18@gmail.com', '08282891', 'dada');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penumpang`
--
ALTER TABLE `penumpang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `terminal`
--
ALTER TABLE `terminal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tiket`
--
ALTER TABLE `tiket`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `penumpang`
--
ALTER TABLE `penumpang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `terminal`
--
ALTER TABLE `terminal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tiket`
--
ALTER TABLE `tiket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
